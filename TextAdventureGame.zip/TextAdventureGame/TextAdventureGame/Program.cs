﻿using TextAdventureGame;

TextAdventure game = new TextAdventure();
game.Run();